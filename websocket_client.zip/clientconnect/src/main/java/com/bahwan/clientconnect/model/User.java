package com.bahwan.clientconnect.model;

public class User {

	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public User(int id) {
		super();
		this.id = id;
	}

	public User() {
		super();

	}
}
