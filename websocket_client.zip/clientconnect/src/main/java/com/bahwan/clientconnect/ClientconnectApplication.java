package com.bahwan.clientconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientconnectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientconnectApplication.class, args);
	}

}
