package com.bahwan.clientconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientconnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
